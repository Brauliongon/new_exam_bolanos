#!/usr/bin/env python

import rospy
from new_exam_bolanos.msg import TopicAC
from new_exam_bolanos.msg import TopicBA
from new_exam_bolanos.srv import *

def talkerA():
	talkerA_topic = rospy.Publisher('chatterA', TopicAC, queue_size = 20)
	rospy.init_node('talkerA', anonymous = True)
	rate = rospy.Rate(10)
	infoA = TopicAC()
	infoA.name = "lazaro"
	while not rospy.is_shutdown():
		#rospy.loginfo("%s",infoA.name)
		talkerA_topic.publish(infoA)
		rospy.Subscriber("chatterB", TopicBA, NowLoadingA)
		rate.sleep()

def NowLoadingA(A1):
	talkerA_n_topic = rospy.Publisher('chatterA_n', TopicBA, queue_size = 20)
	rate = rospy.Rate(10)
	infoA_n = TopicBA()
	infoA_n.name = A1.name
	infoA_n.apellido = A1.apellido
	infoA_n.edad = A1.edad
	#rospy.loginfo("Hello %s %s and your age is %s",B1.name,B1.apellido, infoB.edad)
	#talkerA_n_topic.publish(infoA_n)
	rospy.loginfo(Datos1_client(infoA_n.name,A1.apellido,A1.edad))


def Datos1_client(a,b,c):
	rospy.wait_for_service('datos1')
	try:
		datos1 = rospy.ServiceProxy('datos1', data)
		resp1 = datos1(a,b,c)
		return resp1.response
	except rospy.ServiceException, e:
		print "Service call failed %s"%e

if __name__ == '__main__':
	try:
		talkerA()
	except rospy.ROSInterruptException:
		pass
