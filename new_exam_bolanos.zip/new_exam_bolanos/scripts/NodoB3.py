#!/usr/bin/env python

import rospy
from new_exam_bolanos.msg import TopicCB3
from new_exam_bolanos.msg import TopicBA3

def listenerB3():
	rospy.init_node('listenerB3', anonymous = True)
	rospy.Subscriber("chatterC3", TopicCB3, NowLoadingB3)
	rospy.spin()



def NowLoadingB3(B3):
	talkerB3_topic = rospy.Publisher('chatterB3', TopicBA3, queue_size = 20)
	rate = rospy.Rate(10)
	infoB3 = TopicBA3()
	infoB3.team = B3.team
	infoB3.win = B3.win
	infoB3.when = "mucho"
	#rospy.loginfo("Hello %s %s and you are from %s",B3.animal,B3.color, infoB3.pais)
	talkerB3_topic.publish(infoB3)



if __name__ == '__main__':
	listenerB3()
