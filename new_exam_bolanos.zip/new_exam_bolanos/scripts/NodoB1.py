#!/usr/bin/env python

import rospy
from new_exam_bolanos.msg import TopicCB
from new_exam_bolanos.msg import TopicBA

def listenerB():
	rospy.init_node('listenerB', anonymous = True)
	rospy.Subscriber("chatterC", TopicCB, NowLoadingB)
	rospy.spin()



def NowLoadingB(B1):
	talkerB_topic = rospy.Publisher('chatterB', TopicBA, queue_size = 20)
	rate = rospy.Rate(10)
	infoB = TopicBA()
	infoB.name = B1.name
	infoB.apellido = B1.apellido
	infoB.edad = "la"
	#rospy.loginfo("Hello %s %s and your age is %i",B1.name,B1.apellido, infoB.edad)
	talkerB_topic.publish(infoB)



if __name__ == '__main__':
	listenerB()
