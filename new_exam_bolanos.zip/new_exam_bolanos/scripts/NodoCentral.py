#!/usr/bin/env python

from new_exam_bolanos.srv import *
import rospy

global hola

def respuesta(a):
    hola = "Returning: [ %s %s %s.]"%(a.a,a.b,a.c)
    return dataResponse(hola)

def respuesta2(b):
	hola = "Returning: [ %s %s %s.]"%(b.d,b.e,b.f)
	return data2Response(hola)

def respuesta3(c):
    hola = "Returning: [ %s %s %s.]"%(c.g,c.h,c.i)
    return data3Response(hola)

def Datos1_server():
    rospy.init_node('datos1_server')
    s = rospy.Service('datos1', data, respuesta)
    print "Ready to add data1."

    q = rospy.Service('datos3', data3, respuesta3)
    print "Ready to add data3."
    
    w = rospy.Service('datos2', data2, respuesta2)
    print "Ready to add data2."
    rospy.spin()

if __name__ == "__main__":
    Datos1_server()
