#!/usr/bin/env python

import rospy
from new_exam_bolanos.msg import TopicAC3
from new_exam_bolanos.msg import TopicCB3

def listenerC3():
	rospy.init_node('listenerC3', anonymous = True)
	rospy.Subscriber("chatterA3", TopicAC3, NowLoadingC3)
	rospy.spin()



def NowLoadingC3(C3):
	talkerC3_topic = rospy.Publisher('chatterC3', TopicCB3, queue_size = 20)
	rate = rospy.Rate(10)
	infoC3 = TopicCB3()
	infoC3.team = C3.team
	infoC3.win = "gusta"
	#rospy.loginfo("Hello %s %s",C3.animal,infoC3.color)
	talkerC3_topic.publish(infoC3)



if __name__ == '__main__':
	listenerC3()
